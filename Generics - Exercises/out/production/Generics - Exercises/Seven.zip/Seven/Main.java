package Seven;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();
        CustomList<String> list = new CustomList<>();

        String[] tokens = input.split("\\s+");
        String commandName = tokens[0];

        while (!commandName.equalsIgnoreCase("end")) {

            switch (commandName) {
                case "Add":
                    String element = tokens[1];
                    list.add(element);
                    break;
                case "Remove":
                    int removeIndex = Integer.parseInt(tokens[1]);
                    list.remove(removeIndex);
                    break;
                case "Contains":
                    String containsElement = tokens[1];
                    System.out.println(list.contains(containsElement));
                    break;
                case "Swap":
                    int firstIndex = Integer.parseInt(tokens[1]);
                    int secondIndex = Integer.parseInt(tokens[2]);
                    list.swap(firstIndex,secondIndex);
                    break;
                case "Greater":
                    String greaterElement = tokens[1];
                    System.out.println(list.countGreaterThan(greaterElement));
                    break;
                case "Max":
                    System.out.println(list.getMax());
                    break;
                case "Min":
                    System.out.println(list.getMin());
                    break;
                case "Print":
                    System.out.println(list);
                    break;

            }
            commandName = scanner.nextLine();
        }
    }
}
