package groomingSalon;


import java.util.ArrayList;
import java.util.List;

public class GroomingSalon {
    private List<Pet> petList ;
    private int capacity;


    public GroomingSalon (int capacity){
        petList = new ArrayList<>();
    }

    public List<Pet> getPetList() {
        return petList;
    }

    public int getCapacity() {
        return capacity;
    }
    public void add(Pet pet){
        if(this.petList.size() < this.getCapacity()){
            this.petList.add(pet);
        }
    }
    public boolean remove(String name){
        return this.getPetList().removeIf(element -> element.getName().contains(name));
    }
    public Pet getPet(String name, String owner){
        return this.petList.stream().filter(e -> e.getName().equals(name))
                .filter(e->e.getOwner().equals(owner)).findAny().orElse(null);
    }
     public int getCount(){
        return this.petList.size();
     }
     public String getStatistics(){
           StringBuilder sb = new StringBuilder();

         for (Pet pet : petList) {
             sb.append(String.format("The grooming salon has the following clients:%s %s",pet.getName(), pet.getOwner()));
             sb.append(System.lineSeparator());
         }
         return sb.toString().trim();
     }

}
